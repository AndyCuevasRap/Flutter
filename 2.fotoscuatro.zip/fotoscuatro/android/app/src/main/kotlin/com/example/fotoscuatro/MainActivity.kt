package com.example.fotoscuatro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
