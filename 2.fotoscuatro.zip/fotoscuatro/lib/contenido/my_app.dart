import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Galeria con container",
      home: Scaffold(
        backgroundColor: Colors.green[500],
        appBar: AppBar(
          title: Text(
            "Gallery 4 pics",
            style: GoogleFonts.englebert(
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.green[900],
        ),
        body: Center(
          child: _buildImageColumn(),
        ),
        bottomNavigationBar: SizedBox(
          height: 40,
          child: BottomAppBar(
            color: Colors.green[900],
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Andrés Cuevas",
                  style: GoogleFonts.englebert(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

// #inicio_construccion_por_column
  Widget _buildImageColumn() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.black26,
      ),
      child: SingleChildScrollView(
          child: Align(
        alignment: Alignment.center,
        widthFactor: 1,
        heightFactor: 1,
        child: Column(
          children: [
            _buildImageRow(1),
            _buildImageRow(3),
          ],
        ),
      )),
    );
  }
  // #fin_construccion_por_column

  // #inicio_construccion_por_row
  Widget _buildDecoratedImage(int imageIndex) => Expanded(
        child: Container(
          width: 150,
          //height: 300,
          decoration: BoxDecoration(
            border: Border.all(width: 10, color: Colors.black38),
            borderRadius: const BorderRadius.all(Radius.circular(8)),
          ),
          margin: const EdgeInsets.all(4),
          child: Image.asset("img/pic$imageIndex.jpg"),
        ),
      );

  Widget _buildImageRow(int imageIndex) => Row(
        children: [
          _buildDecoratedImage(imageIndex),
          _buildDecoratedImage(imageIndex + 1),
        ],
      );
  // #fin_construccion_por_row
}
