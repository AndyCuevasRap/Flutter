package com.example.dashbooard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
