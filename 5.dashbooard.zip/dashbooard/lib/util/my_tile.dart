import 'package:flutter/material.dart';

class MyTile extends StatelessWidget {
  final int count;

  const MyTile({Key? key, required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 150,
        decoration: BoxDecoration(
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage("img/img${count + 1}.jpg"),
            ),
            borderRadius: BorderRadius.circular(8),
            color: Colors.brown[200]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            TextButton(
              style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(
                  Colors.brown,
                ),
                alignment: Alignment.bottomRight,
              ),
              onPressed: () {},
              child: const Text("See more"),
            ),
            Center(
              child: Column(children: [
                // Descripciones de los productos
                if (count == 0) ...[
                  Text("Arroz con salsa"),
                  // Product 2
                ] else if (count == 1) ...[
                  Text("Torta de jamon"),
                  // Product 3
                ] else if (count == 2) ...[
                  Text("Pizza"),
                  // Product 4
                ] else if (count == 3) ...[
                  Text("Bandeja paisa"),
                  // Product 5
                ] else if (count == 4) ...[
                  Text("Lasagna"),
                  // Product 6
                ] else if (count == 5) ...[
                  Text("Mariscos"),
                  // Product 7
                ] else if (count == 6) ...[
                  Text("Pasta"),
                  // Product 8
                ] else if (count == 7) ...[
                  Text("Qatro"),
                  // Product 9
                ] else if (count == 8) ...[
                  Text("Jugo de naranja"),
                  // Product 10
                ] else if (count == 9) ...[
                  Text("Café"),
                ],
              ]),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                shape: CircleBorder(),
                padding: EdgeInsets.all(25),
              ),
              child: const Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
