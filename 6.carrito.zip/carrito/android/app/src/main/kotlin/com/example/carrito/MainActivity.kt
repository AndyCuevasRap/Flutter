package com.example.carrito

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
